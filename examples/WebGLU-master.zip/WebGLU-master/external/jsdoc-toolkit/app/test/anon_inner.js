/**
 * @name bar
 * @namespace
 */
 
new function() {
    /**
     * @name bar-foo
     * @function
     * @param {number} x
     */
    function foo(x) {
    }
}