$W.initConstants = function() {
    /** @namespace Contains (semi)constant values that generally shouldn't be 
     * changed.
     */
    $W.constants = {};

    /** @namespace Color constants */
    $W.constants.colors = {
      RED  :[1.0, 0.0, 0.0],
      GREEN:[0.0, 1.0, 0.0],
      BLUE :[0.0, 0.0, 1.0],
      GREY :[0.5, 0.5, 0.5],
      WHITE:[1.0, 1.0, 1.0],
      BLACK:[0.0, 0.0, 0.0]
    };

    /** The name that a uniform variable needs to have to be automatically
     * identified as the Model-View Matrix.
     */
    $W.constants.ModelViewUniform    = 'ModelViewMatrix',

    /** The name that a uniform variable needs to have to be automatically
     * identified as the Projection Matrix.
     */
    $W.constants.ProjectionUniform   = 'ProjectionMatrix',

    /** The name that a uniform variable needs to have to be automatically
     * identified as the Normal Matrix.
     */
    $W.constants.NormalMatrixUniform = 'NormalMatrix'


    /** Data for a unit cube.
     * Intended to be used with setElements.
     */
    $W.constants.unitCube = {
        /** Vertices on the unit cube. */
        vertices : [
            // Front face
            -1.0, -1.0,  1.0,
             1.0, -1.0,  1.0,
             1.0,  1.0,  1.0,
            -1.0,  1.0,  1.0,
            
            // Back face
            -1.0, -1.0, -1.0,
            -1.0,  1.0, -1.0,
             1.0,  1.0, -1.0,
             1.0, -1.0, -1.0,
            
            // Top face
            -1.0,  1.0, -1.0,
            -1.0,  1.0,  1.0,
             1.0,  1.0,  1.0,
             1.0,  1.0, -1.0,
            
            // Bottom face
            -1.0, -1.0, -1.0,
             1.0, -1.0, -1.0,
             1.0, -1.0,  1.0,
            -1.0, -1.0,  1.0,
            
            // Right face
             1.0, -1.0, -1.0,
             1.0,  1.0, -1.0,
             1.0,  1.0,  1.0,
             1.0, -1.0,  1.0,
            
            // Left face
            -1.0, -1.0, -1.0,
            -1.0, -1.0,  1.0,
            -1.0,  1.0,  1.0,
            -1.0,  1.0, -1.0

        ],
          
        /** Normals on the unit cube. */
        normals : [
            // Front
             0.0,  0.0,  1.0,
             0.0,  0.0,  1.0,
             0.0,  0.0,  1.0,
             0.0,  0.0,  1.0,
            
            // Back
             0.0,  0.0, -1.0,
             0.0,  0.0, -1.0,
             0.0,  0.0, -1.0,
             0.0,  0.0, -1.0,
            
            // Top
             0.0,  1.0,  0.0,
             0.0,  1.0,  0.0,
             0.0,  1.0,  0.0,
             0.0,  1.0,  0.0,
            
            // Bottom
             0.0, -1.0,  0.0,
             0.0, -1.0,  0.0,
             0.0, -1.0,  0.0,
             0.0, -1.0,  0.0,
            
            // Right
             1.0,  0.0,  0.0,
             1.0,  0.0,  0.0,
             1.0,  0.0,  0.0,
             1.0,  0.0,  0.0,
            
            // Left
            -1.0,  0.0,  0.0,
            -1.0,  0.0,  0.0,
            -1.0,  0.0,  0.0,
            -1.0,  0.0,  0.0

        ],
          
        /** Texture coordinates on the unit cube. */
        texCoords : [
            // Front
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0,
            // Back
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0,
            // Top
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0,
            // Bottom
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0,
            // Right
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0,
            // Left
            0.0,  0.0,
            1.0,  0.0,
            1.0,  1.0,
            0.0,  1.0
        ],

        /** Per element indices for unit cube */
        indices : [
            0,  1,  2,      0,  2,  3,    // front
            4,  5,  6,      4,  6,  7,    // back
            8,  9,  10,     8,  10, 11,   // top
            12, 13, 14,     12, 14, 15,   // bottom
            16, 17, 18,     16, 18, 19,   // right
            20, 21, 22,     20, 22, 23    // left
        ]
    };

};

