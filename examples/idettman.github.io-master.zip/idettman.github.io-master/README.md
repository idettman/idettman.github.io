# idettman.github.io

### prototype using preact, rollup, buble and post css
### custom build tools
- vanilla nodejs postcss runner
- vanilla nodejs http server for single page front end routing

### custom postcss runner and http server are modular and independent of the front end javascript build tool
