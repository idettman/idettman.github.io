export const NAV_DATA = {
	home: {
		path: '/',
		title: 'home'
	},
	repos: {
		path: '/repos',
		title: 'git repos'
	}
}
