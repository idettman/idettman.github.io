# Ramda transducer example

```javascript
npm install
node script
```
