export function scaledPosition(pos, scale) {
  return pos * scale;
}

export default scaledPosition;
