export function isSamePosition(a, b) {
  return a.x === b.x && a.y === b.y;
}

export default isSamePosition;
