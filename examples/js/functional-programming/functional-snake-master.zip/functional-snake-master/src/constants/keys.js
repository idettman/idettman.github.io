export const SPACE_KEY = 32;
export const PAUSE_KEY = 80;
