export const GAME_WIDTH = 30;
export const GAME_HEIGHT = 30;
export const GAME_SCALE = 10;
