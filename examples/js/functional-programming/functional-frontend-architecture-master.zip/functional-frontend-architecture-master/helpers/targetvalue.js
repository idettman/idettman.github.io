module.exports = function(ev) {
  return ev.target.value;
};
