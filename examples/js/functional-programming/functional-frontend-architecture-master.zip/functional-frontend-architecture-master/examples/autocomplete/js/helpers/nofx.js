module.exports = function noFx(s){ return [s,[]]; } 

