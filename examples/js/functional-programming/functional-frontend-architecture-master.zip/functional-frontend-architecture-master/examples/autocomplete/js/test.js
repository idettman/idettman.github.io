
require('source-map-support').install();

require('./test-unit-menu');
require('./test-unit-autocomplete');
require('./test-app');
