var path = require('ramda/src/path');
module.exports = path(['target', 'value']);

