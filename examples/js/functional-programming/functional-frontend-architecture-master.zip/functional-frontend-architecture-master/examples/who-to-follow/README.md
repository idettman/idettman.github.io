# Who to follow

Based on [the
example](https://github.com/paldepind/flyd/tree/master/examples/who-to-follow)
from flyd's repo, which is based on http://jsfiddle.net/staltz/8jFJH/48/.

## Building

```sh
npm install
npm run build
```

## Automatic reload

```sh
npm install -g watchify browser-sync
npm run watch
```
