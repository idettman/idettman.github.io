WebGL Shader demos - GPU rendering shader experiments with procedural 3D scene generation using ray marching and distance field (also known as 'sphere tracing') rendering techniques.

by Kevin Roast - see http://www.kevs3d.co.uk/dev/shaders/ for live demos and screenshots.

- Lots of code/ideas for these come from reading:
 
     http://www.iquilezles.org/www/material/nvscene2008/rwwtt.pdf

     http://www.pouet.net/topic.php?which=7931&page=1
     
     http://www.pouet.net/topic.php?which=7920&page=1
     
     http://iquilezles.org/www/articles/distfunctions/distfunctions.htm
     
     https://www.shadertoy.com/
   
If you want to understand this stuff read through the PDF and pouet.net links above
