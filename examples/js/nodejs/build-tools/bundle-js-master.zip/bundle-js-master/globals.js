
module.exports = {
    DEFAULT_OUTPUT_FILE: './bundlejs/output.js'
}
