"use strict";

module.exports.name = "outer";
