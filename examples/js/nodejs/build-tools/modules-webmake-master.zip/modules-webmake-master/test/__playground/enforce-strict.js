// eslint-disable-next-line strict
module.exports = (function () { return this; }());
