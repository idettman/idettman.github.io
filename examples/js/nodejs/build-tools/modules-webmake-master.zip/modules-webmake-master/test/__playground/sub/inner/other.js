"use strict";

exports.id = "sub-inner-other";
