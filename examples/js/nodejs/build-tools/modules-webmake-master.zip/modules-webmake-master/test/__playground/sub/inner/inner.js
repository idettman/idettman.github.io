"use strict";

exports.id = "sub-inner-inner";
exports.outer = require("../../sub-longer/other");
