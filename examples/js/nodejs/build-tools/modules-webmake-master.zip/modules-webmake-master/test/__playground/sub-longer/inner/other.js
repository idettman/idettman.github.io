"use strict";

exports.id = "sub-longer-inner-other";
exports.outer = require("../../sub/inner/other");
