"use strict";

exports.id = "sub-foo";
exports.subOuter = require("../sub-longer/inner/other");
