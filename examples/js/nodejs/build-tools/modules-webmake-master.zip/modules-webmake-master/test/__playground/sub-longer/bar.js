"use strict";

exports.id = "sub-longer-bar";
exports.sub = require("../sub/foo");
exports.subInner = require("../sub/inner/inner");
