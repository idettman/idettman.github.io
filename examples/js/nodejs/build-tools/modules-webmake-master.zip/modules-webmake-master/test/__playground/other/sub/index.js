"use strict";

exports.name = "outer-index";
