"use strict";

exports.fs = require("fs");
