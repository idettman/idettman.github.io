var Bitloader = require("@bit/loader");
module.exports = Bitloader.logger;
