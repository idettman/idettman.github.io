/*eslint no-console: ["off"]*/
require("spromise/dist/spromise.min");

module.exports = {
  roast: "this",
  potatoes: function() {
    console.log("Say potatoes");
  }
};
