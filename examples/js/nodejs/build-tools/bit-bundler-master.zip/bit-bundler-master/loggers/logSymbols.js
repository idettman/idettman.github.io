var logSymbols = require("log-symbols");
module.exports = Object.assign({
  package: "📦"
}, logSymbols);
