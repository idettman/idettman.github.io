<img src="https://raw.githubusercontent.com/MiguelCastillo/bit-bundler/master/img/bit-bundler_white.png" width="100%"></img>

[![Build Status](https://travis-ci.org/MiguelCastillo/bit-bundler.svg?branch=master)](https://travis-ci.org/MiguelCastillo/bit-bundler) [![Greenkeeper badge](https://badges.greenkeeper.io/MiguelCastillo/bit-bundler.svg)](https://greenkeeper.io/)

> JavaScript bundler for your Web Application.

[Documentation can be found here](https://bundler.bitjs.io/)


## License

Licensed under MIT
