## Requirements

The requirements are node version 4 (or later) as the environment as well as npm, yarn, or equivalent to install packages. Throughout the docs, unless otherwise stated, the assumption is that your environment is node.
