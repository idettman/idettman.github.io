module.exports = () => "hello";
