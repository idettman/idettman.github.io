module.exports = () => "world";
