module.exports = {
  "root": "./dist"
};
