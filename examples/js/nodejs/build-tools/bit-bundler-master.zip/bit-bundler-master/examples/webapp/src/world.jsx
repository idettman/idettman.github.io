import React from "react";
import Span from "./span.jsx";

export default function World() {
  return <Span>World</Span>;
}
