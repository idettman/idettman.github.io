/**
 * hello world module
 */

import React from "react";
import Span from "./span.jsx";

export default function Hello() {
  return <Span>Hello</Span>;
}
