import React from "react";

export default function Span(props) {
  return <span>{ props.children }</span>;
}
