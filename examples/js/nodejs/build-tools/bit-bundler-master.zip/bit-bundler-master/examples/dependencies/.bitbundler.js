module.exports = {
  src: "src/main.js",
  dest: "dist/out.js"
};
