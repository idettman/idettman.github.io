const helloWorld = require('./hello-world');
const log2console = require('log2console');

log2console(helloWorld);
