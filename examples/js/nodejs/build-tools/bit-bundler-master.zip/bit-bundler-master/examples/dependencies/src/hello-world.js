module.exports = "Hello world";
