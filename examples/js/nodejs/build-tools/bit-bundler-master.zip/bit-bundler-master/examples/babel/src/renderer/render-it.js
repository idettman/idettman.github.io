import log2console from 'log2console';

class RenderIt {
  constructor() {
  }

  render() {
    log2console('base render-it!');
  }
}

export default RenderIt;
