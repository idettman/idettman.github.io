module.exports = {
  multiprocess: 1,
  src: "src/main.js",
  dest: "dist/out.js",

  loader: [
    "@bit/loader-babel"
  ]
};
