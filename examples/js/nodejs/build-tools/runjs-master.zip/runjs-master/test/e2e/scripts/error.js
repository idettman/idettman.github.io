throw new Error('error message')
