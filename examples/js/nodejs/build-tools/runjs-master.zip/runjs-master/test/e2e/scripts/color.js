const chalk = require('chalk')

console.log(chalk.yellow('This should be in yellow color'))
