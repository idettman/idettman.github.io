import React from 'react'
import Welcome from '../components/Welcome'

const App = () => (
  <div>
    <Welcome name="guest" />
  </div>
)

export default App
