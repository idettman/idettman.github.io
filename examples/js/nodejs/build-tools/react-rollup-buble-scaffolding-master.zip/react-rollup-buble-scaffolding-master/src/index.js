import React from 'react'
import ReactDOM from 'react-dom'
import App from './containers/App'

const root = document.querySelector('#app')

ReactDOM.render(<App/>, root)
