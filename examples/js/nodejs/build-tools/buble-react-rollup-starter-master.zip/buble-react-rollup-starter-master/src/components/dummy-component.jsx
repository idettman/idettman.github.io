// Import React.
import React from 'react'

export class DummyComponent extends React.Component {
  render () {
    return (
      <article>
        <h1>Hi from DummyComponent.</h1>
        <em>Now let's play with React!</em>
      </article>
    )
  }
}
