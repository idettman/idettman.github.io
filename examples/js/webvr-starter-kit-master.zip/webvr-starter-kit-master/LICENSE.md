# Software License (MIT)

Copyright (c) 2015 American Documentary Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

# Texture Licenses

Bricks
http://textures.thefree3dmodels.com/stuff/brick/bricks_diffuse/2-1-0-688
Attribution-Noncommercial-Share Alike 3.0 Unported License

Wood
http://textures.thefree3dmodels.com/stuff/wood/free_wood_texture_tilable/36-1-0-681
Attribution-Noncommercial-Share Alike 3.0 Unported License

Weathered Wood
http://freeseamlesstextures.com/gallery/45-weathered-wood-background.html
Creative Commons Attribution 3.0 United States

Asphalt
http://freeseamlesstextures.com/gallery/41-black-asphalt-background.html
Creative Commons Attribution 3.0 United States

Stone
http://freeseamlesstextures.com/gallery/12-natural-stone-background.html
Creative Commons Attribution 3.0 United States

Tiles
http://www.brusheezy.com/textures/22875-10-seamless-ceramic-tiles-textures
Creative Commons Attribution 3.0 Unported License

Brick Tiles
http://www.brusheezy.com/textures/22875-10-seamless-ceramic-tiles-textures
Creative Commons Attribution 3.0 Unported License

Metal Floor
http://agf81.deviantart.com/art/Seamless-Floor-Special-322523166
Creative Commons Attribution 3.0 License

Metal
http://hhh316.deviantart.com/art/Seamless-metal-texture-smooth-164165216
Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 License

Grass
http://seamlesstextures.deviantart.com/art/Seamless-grass-texture-163548160
Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 License
