// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once
#define M_PI 3.141592

#include "gnu_ballistics.h"
