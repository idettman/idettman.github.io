﻿using System.Windows.Controls;

namespace Sharp.Ballistics.Calculator.Views
{
    /// <summary>
    /// Interaction logic for CalculatorView.xaml
    /// </summary>
    public partial class CalculatorView
    {
        public CalculatorView()
        {
            InitializeComponent();
        }    
    }
}
