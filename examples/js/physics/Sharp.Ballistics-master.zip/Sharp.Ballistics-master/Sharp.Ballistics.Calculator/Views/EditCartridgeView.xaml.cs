﻿using System.Windows;

namespace Sharp.Ballistics.Calculator.Views
{
    public partial class EditCartridgeView : Window
    {
        public EditCartridgeView()
        {
            InitializeComponent();
        }
    }
}
