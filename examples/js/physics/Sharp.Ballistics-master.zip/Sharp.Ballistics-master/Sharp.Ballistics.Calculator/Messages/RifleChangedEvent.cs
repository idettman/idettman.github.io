﻿using Sharp.Ballistics.Calculator.Models;

namespace Sharp.Ballistics.Calculator.Util
{
    public class RifleChangedEvent
    {
        public Rifle ChangedRifle { get; set; }
    }
}
