﻿namespace Sharp.Ballistics.Calculator
{
    public class ExportImportEvent
    {
        public bool IsInProgress { get; set; }

        public string Message { get; set; }
    }
}
