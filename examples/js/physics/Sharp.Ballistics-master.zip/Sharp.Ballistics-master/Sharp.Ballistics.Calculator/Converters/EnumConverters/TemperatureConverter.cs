﻿using UnitsNet.Units;

namespace Sharp.Ballistics.Calculator
{
    public class TemperatureConverter : HumanizeEnumConverter<TemperatureUnit>
    {
    }
}
