﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sharp.Ballistics.Training
{
    public static class Constants
    {
        public const string DataFolder = "App_Data";
        public const string DatabaseName = "Sharp.Ballistics.Training";
    }
}