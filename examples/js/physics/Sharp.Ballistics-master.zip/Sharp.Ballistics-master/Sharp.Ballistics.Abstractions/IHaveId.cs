﻿namespace Sharp.Ballistics.Abstractions
{
    public interface IHaveId
    {
        string Id { get; }
    }
}
