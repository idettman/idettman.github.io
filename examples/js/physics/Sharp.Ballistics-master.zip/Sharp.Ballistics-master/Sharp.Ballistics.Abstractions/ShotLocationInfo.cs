﻿namespace Sharp.Ballistics.Abstractions
{
    public class ShotLocationInfo
    {
        public double Latitude { get; set; }

        public double ShotAzimuth { get; set; }
    }
}
