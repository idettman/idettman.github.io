﻿namespace Sharp.Ballistics.Abstractions
{
    public enum DragFunction
    {
        G1 = 1,
        G2,
        G3,
        G4,
        G5,
        G6,
        G7,
        G8
    }
}