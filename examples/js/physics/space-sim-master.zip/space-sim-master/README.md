# space-sim

## Getting Started
Install [redux-devtools-extension](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd) for Chrome

```
git clone https://github.com/ashtonwar/space-sim
cd space-sim
npm install
```

## License
ISC
