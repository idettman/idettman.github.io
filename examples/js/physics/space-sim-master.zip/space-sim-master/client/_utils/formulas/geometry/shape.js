const {PI} = Math

export const sphere = {
  volume: radius => (4 * PI * radius ** 3) / 3,
}
