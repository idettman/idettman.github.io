function initModel(envProps) {
	envProps.gCoefficient = 9.8;
	envProps.initialSpeed = 10;
	envProps.mass = 10;
}
