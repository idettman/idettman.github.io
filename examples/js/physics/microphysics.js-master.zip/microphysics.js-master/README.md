microphysics.js is a micro library implementing 3D physics.

all the hard work is from Florian Bosh @pyalot http://codeflow.org


