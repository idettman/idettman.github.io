microphysics.js features:
- rotated box
- plane



THREEx.microphysics.js
- remove scene from microphysics.update()
  - it is needed only to get the bound meshes
  - keep the list in the instance
- make microphysics.js option pass thru 