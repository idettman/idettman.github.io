require "staticmatic/compass"

project_type = :staticmatic