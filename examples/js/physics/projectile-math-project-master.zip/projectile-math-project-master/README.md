# projectile-math-project

Try here: http://sukk4.net/games/math/game.html

2014 math project that shows projectiles trajectory and some information of the trajectory. 

Projectile info: speed, position, air resistance, kinetic energy, time it took to reach 0 ground and average speed. 

You can change air density, caliper, mass, gravity, starting speed, starting position(x,y), angle and drag coefficient.

I made this for math class I took and was planning to use this possibly in some game.

App is in finnish and the code is super messy as I built it on top of 2d-platformer-game ( https://github.com/Sukk4/2D-platformer-game )
