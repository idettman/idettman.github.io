
var canvas = document.getElementById("canvas_id");
var ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 600;
