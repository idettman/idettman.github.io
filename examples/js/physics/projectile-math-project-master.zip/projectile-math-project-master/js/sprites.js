// Pictures/textures

var playerLoaded = false;
		var playerImg = new Image();
		playerImg.onload = function() {
		  playerLoaded = true;
		};
		playerImg.src = "textures/bullet.png";
		



	
		var backgroundLoaded = false;
		var backgroundImg = new Image();
		backgroundImg.onload = function() {
		  backgroundLoaded = true;
		};
		backgroundImg.src = "textures/background.png";


		var bulletLoaded = false;
		var bulletImg = new Image();
		bulletImg.onload = function() {
		  bulletLoaded = true;
		};
		bulletImg.src = "textures/bullet.png"

		