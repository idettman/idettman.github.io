# traj-utilities

Calculate conditional probabilities for a multi-trajectory model fitted by *traj*.
