var View = {
	reset: function () {
		
	},
	
	clear: function() {
		
	},
	
	addHost: function(name, type, label, x, y, yindex){
		
	},
	
	connect: function(from, to){
		
	},
	
	addInfo: function(time, at, msg, duration){
		
	},
	
	addPacket: function(time, from, to, msg){
		
	},
	
	addPacketDrop: function(time, at, msg){
		
	},
	
	addTable: function(host, name, title, nrows, ncols, x, y){
		
	},
	
	setTableVal: function(node, name, row, col, val){
		
	},
	
	addDiv: function(host, div, x, y){
		
	},
	
	step: function(){
		
	},
};