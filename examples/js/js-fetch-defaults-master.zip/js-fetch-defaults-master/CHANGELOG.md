## 1.0.0 (Aug 31, 2016)
- Unscoped release for public use and personal profit.

## 0.1.337 (Dec 11, 2015)
- Scoped release for personal use and profit.
