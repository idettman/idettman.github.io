require(["texture-util/loader"], function(TextureUtil) {
    // And then some cool stuff happened!
    window['TextureUtil'] = TextureUtil;
}, "export", true);