Crunch
=========

crn_decomp.h and crlib.h are part of the Crunch texture compression library by Rich Geldreich, (http://www-cs-students.stanford.edu/~eparker/files/crunch/decode_test.html)

crn.cpp is a modification of the original emscripten wrapper code by Evan Parker, (http://www-cs-students.stanford.edu/~eparker/files/crunch/decode_test.html)

