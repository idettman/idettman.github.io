#!/bin/bash

node requirejs/r.js -o name=requirejs/almond.js include=texture-util/export out=build/texture-util.js baseUrl=. wrap=true