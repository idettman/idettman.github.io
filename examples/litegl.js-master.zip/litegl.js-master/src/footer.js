
//footer.js
})( typeof(window) != "undefined" ? window : (typeof(self) != "undefined" ? self : global ) );