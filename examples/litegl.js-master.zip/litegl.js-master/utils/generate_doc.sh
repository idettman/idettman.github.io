yuidoc ../src -o ../doc
