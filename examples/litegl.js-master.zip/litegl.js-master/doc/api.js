YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "BBox",
        "GL",
        "GL.Buffer",
        "GL.FBO",
        "GL.Indexer",
        "GL.Mesh",
        "GL.Octree",
        "GL.Shader",
        "GL.Texture",
        "LEvent",
        "geo",
        "gl"
    ],
    "modules": [],
    "allModules": [],
    "elements": []
} };
});