# CUI.js
an UI framework based on HTML5 Canvas
