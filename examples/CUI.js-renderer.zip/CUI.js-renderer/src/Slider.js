"use strict";

var CUI = CUI || {};

(function(exports) {

    var Class = exports.Class;

    var Slider = Class.create({

        initialize: function() {
            this.velX = 0;
            this.velY = 0;
            this.accX = 0;
            this.accY = 0;
            this.damping = 0.003;
            this.dx = 0;
            this.dy = 0;
            this.entity = null;
        },

        init: function(entity) {
            this.entity = entity || this.entity;
        },

        reset: function() {
            this.started = false;
            this.toStart = false;

            var entity = this.entity;
            this.dx = this.dy = this.velX = this.velY = this.accX = this.accY = 0;
        },

        start: function(vx, vy, force) {
            if (this.toStart || force) {
                // vx*=0.75;
                // vy*=0.75;

                var entity = this.entity;
                this.velX = vx || 0;
                this.velY = vy || 0;

                this.toStart = false;
                this.started = true;
            } else {
                this.started = false;
            }
        },

        stop: function() {
            this.reset();
        },

        applyDamping: function(timeStep) {
            var d = 1 - timeStep * this.damping;
            (d < 0) && (d = 0);
            (d > 1) && (d = 1);
            this.velX *= d;
            this.velY *= d;
        },

        update: function(timeStep) {
            if (!this.started) {
                return false;
            }
            var entity = this.entity;

            var lastVelX = this.velX;
            var lastVelY = this.velY;
            this.applyDamping(timeStep);

            // var dx = (lastVelX+this.velX) / 2 * timeStep;
            // var dy = (lastVelY+this.velY) / 2 * timeStep;


            if (Math.abs(this.velX) > 0.033 || Math.abs(this.velY) > 0.033) {
                var dx = this.velX * timeStep;
                var dy = this.velY * timeStep;

                this.dx = dx;
                this.dy = dy;

                return true;

            } else {

                this.stop();

                return false;
            }
        }

    });

    exports.Slider = Slider;

    if (typeof module !== "undefined") {
        module.exports = Slider;
    }

}(CUI));
