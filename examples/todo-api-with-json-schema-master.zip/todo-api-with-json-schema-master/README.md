# todo-api-with-json-schema

[![CircleCI](https://circleci.com/gh/bahmutov/todo-api-with-json-schema.svg?style=svg)](https://circleci.com/gh/bahmutov/todo-api-with-json-schema) [![renovate-app badge][renovate-badge]][renovate-app]

[Schemas](schemas.md)

[renovate-badge]: https://img.shields.io/badge/renovate-app-blue.svg
[renovate-app]: https://renovateapp.com/
